import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

const Acccounts = (props) => {
  return (
    <React.Fragment>
      <div>
        <Link to={`/report`}>Report</Link>
        <span> | </span>
        <Link to={`/accounts`}>Accounts</Link>
      </div>
      <div style={{ margin: "25px 0px" }}>Accounts</div>
    </React.Fragment>
  );
};

export default Acccounts;
