import React, { useState, useEffect } from "react";
import { useSearchContext } from "./context";

export const searchAccounts = (accountType) => {
  const mock = [
    { name: "breakfast", type: "income", amount: "100" },
    { name: "lunch", type: "income", amount: "100" },
    { name: "gas", type: "income", amount: "100" },
    { name: "drink", type: "expense", amount: "100" },
    { name: "fruit1", type: "expense", amount: "100" },
    { name: "fruit2", type: "expense", amount: "100" },
    { name: "fruit2", type: "expense", amount: "100" },
  ];
  return mock.filter((v) => v.type === accountType);
};

const SearchInput = () => {
  const searchContext: any = useSearchContext();

  const updateResults = (results) => {
    searchContext.setResults(results);
    searchContext.setPageCount(3);
  };

  const handleAccountTypeChanged = (event) => {
    searchContext.setAccountType(event.target.value);
  };

  useEffect(() => {
    updateResults(searchAccounts(searchContext.accountType));
  }, [searchContext.accountType]);

  return (
    <div>
      <select onChange={handleAccountTypeChanged}>
        <option
          key={"income"}
          value={"income"}
          selected={searchContext.accountType === "income"}
        >
          Income
        </option>
        <option
          key={"expense"}
          value={"expense"}
          selected={searchContext.accountType === "expense"}
        >
          Expense
        </option>
      </select>
    </div>
  );
};

export default SearchInput;
