import React from "react";
import { BrowserRouter as Router, Route, Redirect } from "react-router-dom";
import { SearchContextProvider } from "./context";
import Accounts from "./accounts";
import Report from "./report";

function Nav() {
  return (
    <SearchContextProvider>
      <Router>
        <Route exact path="/" render={() => <Redirect to="/Report" />} />
        <Route path="/accounts" component={Accounts} />
        <Route path="/report" component={Report} />
      </Router>
    </SearchContextProvider>
  );
}

export default Nav;
