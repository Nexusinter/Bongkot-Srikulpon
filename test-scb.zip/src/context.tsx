import React, { createContext, useContext, useState } from "react";
import { node, string } from "prop-types";

export const SearchContext: any = createContext({});

export const SearchContextProvider = ({ children }) => {
  const [accountType, setAccountType] = useState("income");
  const [results, setResults] = useState([]);
  const [pageCount, setPageCount] = useState([]);
  const [pageSize, setPageSize] = useState(10);
  const [offset, setOffset] = useState(1);

  const searchContext = {
    results,
    setResults: setResults,
    accountType,
    setAccountType,
    pageCount,
    setPageCount: setPageCount,
    offset,
    setOffset: setOffset,
    pageSize,
  };
  return (
    <SearchContext.Provider value={searchContext}>
      {children}
    </SearchContext.Provider>
  );
};

SearchContextProvider.propTypes = {
  children: node.isRequired,
  queryString: string,
};

export const useSearchContext = () => useContext(SearchContext);
