import React from "react";
import ReactDOM from "react-dom";
import Nav from "./route.js";

class App extends React.Component {
  render() {
    return (
      <React.Fragment>
        <div>
          <Nav />
        </div>
      </React.Fragment>
    );
  }
}

ReactDOM.render(<App />, document.getElementById("root"));
