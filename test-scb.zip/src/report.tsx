import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Search from "./search";
import { useSearchContext } from "./context";
import ReactPaginate from "react-paginate";
import "./style.css";

const Home = () => {
  const [results, setResults] = useState([]);
  const searchContext: any = useSearchContext();

  useEffect(() => {
    setResults(searchContext.results);
  }, [searchContext]);

  const handlePageClick = (data) => {
    let selected = data.selected;
    let offset = selected + 1;
    searchContext.setOffset(offset);
  };

  return (
    <React.Fragment>
      <div>
        <Link to={`/report`}>Report</Link>
        <span> | </span>
        <Link to={`/accounts`}>Accounts</Link>
      </div>

      <div style={{ margin: "25px 0px" }}>Report</div>

      <div style={{ margin: "25px 0px" }}>
        <Search />
      </div>

      <div style={{ margin: "25px 0px" }}>
        <h4>Result</h4>
        <ul>
          {results &&
            results.map((result) => (
              <li key={result.name}>
                {result.type} {result.name} {result.amount}
              </li>
            ))}
        </ul>
      </div>
      <div className="react-paginate">
        <ReactPaginate
          previousLabel={"previous"}
          nextLabel={"next"}
          breakLabel={"..."}
          breakClassName={"break-me"}
          pageCount={searchContext.pageCount}
          marginPagesDisplayed={2}
          pageRangeDisplayed={2}
          onPageChange={handlePageClick}
          containerClassName={"pagination"}
          subContainerClassName={"pages pagination"}
          activeClassName={"active"}
        />
      </div>
    </React.Fragment>
  );
};

Home.defaultProps = {};

export default Home;
